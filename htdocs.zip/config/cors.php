<?php
	header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, PATCH, HEAD");
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Credentials: false');
	header("Access-Control-Allow-Headers: Content-Type, Authorization");

	header('Content-Type: application/json; charset=utf-8');
